<?php if(!isset($_SESSION)){session_start();} error_reporting(0);
/* Zetix Arch-Soft Inc. www.Zearch-Soft.com
 * @Copyright Copyright (C) 2017 CMS Zesoft Open Source, Inc. All Rights Reserved.
 * @License		GNU General Public License Version 2 Or Later; See LICENSE.TxT
 * Jeffri Gunawan Jeffrislackware@gmail.com
 */
	require_once '../../Configuration/Configuration.php';
	require_once '../../Library/Php/Session.php';
	include_once '../../Library/Plugin/FPDF/fpdf.php';
	
	// Membuat Objek Baru Bernama pdf Dari Class FPDF
	// Dan Melakukan Setting Kertas l : Landscape, A4 : Ukuran Kertas
	$pdf = new FPDF('l','mm','A4');
	
	// Membuat Halaman Baru
	$pdf->AddPage();
	
	// Menyetel Font Yang Digunakan, Font Yang Digunakan Adalah Arial, Bold Dengan Ukuran 16
	$pdf->SetFont('Arial','B',16);
	
	// Judul

	$pdf->Cell(279,6,'Laporan Penerimaan Bantuan Sosial COVID-19',0,1,'C');
	
	$pdf->Line(10,10,289,10);
	// Kiri,Atas,Lebar,Tinggi
	$pdf->Image('../../Library/Images/Linux.png',40,12,20,20);
	$pdf->Image('../../Library/Images/Apple.png',245,12,20,20);
	$pdf->Line(10,35,289,35);
	
	$pdf->Ln();
	$pdf->Ln();
	$pdf->Ln();
	$pdf->Ln();
	
	$pdf->SetFont('Arial','B',12);
	$Date = date("l d F Y H:i");
	$pdf->Cell(30,6,'Tanggal',0,0);
	$pdf->Cell(4,6,':',0,0);
	$pdf->Cell(62,6,$Date,0,1,'C');
	$pdf->Cell(30,6,'Dicetak Oleh',0,0);
	$pdf->Cell(4,6,':',0,0);
	$pdf->Cell(62,6,$SFName,0,1);
	
	// Memberikan Space Kebawah Agar Tidak Terlalu Rapat
	$pdf->Ln();
	
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(22,6,'NO',1,0,'C');
	$pdf->Cell(40,6,'ID',1,0,'C');
	$pdf->Cell(44,6,'Alokasi',1,0,'C');
	$pdf->Cell(44,6,'Jumlah Transaksi',1,0,'C');
	$pdf->Cell(44,6,'Jumlah Dana',1,0,'C');
	$pdf->Cell(80,6,'Tanggal',1,1,'C');
	
	$pdf->SetFont('Arial','',10);

	//Koneksi Ke Database
	$No = 1;
	$QShow = mysqli_query($Connection,"SELECT * FROM Bantuan");
	while ($QView = mysqli_fetch_array($QShow)){
		$pdf->Cell(22,6,$No++,1,0,'C');
		$pdf->Cell(40,6,$QView['0'],1,0,'C');
		$pdf->Cell(44,6,$QView['1'],1,0);
		$pdf->Cell(44,6,$QView['3'],1,0); 
		$pdf->Cell(44,6,$QView['2'],1,0);
		$pdf->Cell(80,6,$QView['7'],1,1);
	}
	
	$pdf->Output();
?>
<?php
header('Location:CPanel/Index.php');
?>